const s="/document/assets/golangcilint.e31f929a.jpg",t="/document/assets/golangcilintversion.afbdeff6.jpg";export{s as _,t as a};
