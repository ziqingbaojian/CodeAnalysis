const a="/document/assets/manage_oauth_01.3e559946.png",s="/document/assets/manage_oauth_02.5a0227a3.png";export{a as _,s as a};
