const a="/document/assets/manage_team_01.9b57a754.png";export{a as _};
